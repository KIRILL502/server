﻿function import(...) return call(getResourceFromName("editor_main"),"import",...) end
