addEvent("callServerAccountName", true)
addEventHandler("callServerAccountNamecallServerAccountName", getRootElement(),
	function (thePlayer)
		if thePlayer then
			local account = getPlayerAccount(thePlayer)
			if account then
				if isGuestAccount(account) then
					setElementData(thePlayer, "account-name", "Não logado")
				else
					local accountName = getAccountName(account)
					setElementData(thePlayer, "account-name", accountName)
				end
			end
		end
	end
)

addEventHandler("onPlayerLogin", getRootElement(),
	function()
		local accountName = getAccountName(getPlayerAccount(source))
		setElementData(source, "account-name", accountName)
	end
)

addEventHandler("onPlayerLogout", getRootElement(),
	function()
		setElementData(source, "account-name", "Não logado")
	end
)

function setIp()
	if eventName == "onResourceStart" then
		for k, v in ipairs(getElementsByType("player")) do
			setElementData(v, "IP", getPlayerIP(v))
		end
	elseif eventName == "onPlayerJoin" then
		setElementData(source, "IP", getPlayerIP(source))
	end
end
addEventHandler("onResourceStart", getResourceRootElement(getThisResource()), setIp)
addEventHandler("onPlayerJoin", getRootElement(), setIp)

local t = {}

function checkValues(source, arg1, arg2)
	if (arg2 >= 60) then
		t[source]["min"] = tonumber(t[source]["min"] or 0) + 1
		t[source]["sec"] = 0
	end
	if (arg1 >= 60) then
		t[source]["min"] = 0
		t[source]["hour"] = tonumber(t[source]["hour"] or 0) + 1
	end
	return arg1, arg2
end
 
setTimer(
	function()
		for _, v in pairs(getElementsByType("player")) do
			if (not t[v]) then
				t[v] = {
					["hour"] = 0,
					["min"] = 0,
					["sec"] = 0
						}
			end
			t[v]["sec"] = tonumber(t[v]["sec"] or 0) + 1
			local min, sec = checkValues(
				v,
				t[v]["min"] or 0,
				t[v]["sec"] or 0
)
			local hour = tonumber(t[v]["hour"] or 0)
			setElementData(
				v,
				"TempoON",
				tostring(hour).." : "..tostring(min).." : "..tostring(sec)
)
		end
	end,
1000, 0)

function onPlayerQuit()
	local playeraccount = getPlayerAccount(source)
	if (playeraccount) and not isGuestAccount(playeraccount) then
		local sValue = getElementData(source, "TempoON")
		local hour = tonumber(t[source]["hour"] or 0)
		local min = tonumber(t[source]["min"] or 0)
		local sec = tonumber(t[source]["sec"] or 0)
		setAccountData(playeraccount, "TempoON-hour", tostring(hour))
		setAccountData(playeraccount, "TempoON-min", tostring(min))
		setAccountData(playeraccount, "TempoON-sec", tostring(sec))
		setAccountData(playeraccount, "TempoON", tostring(sValue))
	end
	t[source] = nil
end
addEventHandler("onPlayerQuit", getRootElement(), onPlayerQuit)

function onPlayerLogin(_, playeraccount)
	if (playeraccount) then
		local time = getAccountData(playeraccount, "TempoON")
		local hou = getAccountData(playeraccount, "TempoON-hour")
		local min = getAccountData(playeraccount, "TempoON-min")
		local sec = getAccountData(playeraccount, "TempoON-sec")
		if (time) then
			setElementData(source, "TempoON", time)
			t[source]["hour"] = tonumber(hou)
			t[source]["min"] = tonumber(min)
			t[source]["sec"] = tonumber(sec)
		else
			setElementData(source, "TempoON", 0)
			setAccountData(playeraccount, "TempoON", 0)
		end
	end
end
addEventHandler("onPlayerLogin", getRootElement(), onPlayerLogin)

function arma1()
	giveWeapon(source, 1, 1, true)
end
addEvent("arma1", true)
addEventHandler("arma1", getRootElement(), arma1)

function arma2()
	giveWeapon(source, 5, 1, true)
end
addEvent("arma2", true)
addEventHandler("arma2", getRootElement(), arma2)

function arma3()
	giveWeapon(source, 8, 1, true)
end
addEvent("arma3", true)
addEventHandler("arma3", getRootElement(), arma3)

function arma4()
	giveWeapon(source, 4, 1, true)
end
addEvent("arma4", true)
addEventHandler("arma4", getRootElement(), arma4)

function arma5()
	giveWeapon(source, 24, 500, true)
end
addEvent("arma5", true)
addEventHandler("arma5", getRootElement(), arma5)

function arma6()
	giveWeapon(source, 22, 500, true)
end
addEvent("arma6", true)
addEventHandler("arma6", getRootElement(), arma6)

function arma7()
	giveWeapon(source, 23, 500, true)
end
addEvent("arma7", true)
addEventHandler("arma7", getRootElement(), arma7)

function arma8()
	giveWeapon(source, 26, 500, true)
end
addEvent("arma8", true)
addEventHandler("arma8", getRootElement(), arma8)

function arma9()
	giveWeapon(source, 25, 500, true)
end
addEvent("arma9", true)
addEventHandler("arma9", getRootElement(), arma9)

function arma10()
	giveWeapon(source, 27, 500, true)
end
addEvent("arma10", true)
addEventHandler("arma10", getRootElement(), arma10)

function arma11()
	giveWeapon(source, 29, 500, true)
end
addEvent("arma11", true)
addEventHandler("arma11", getRootElement(), arma11)

function arma12()
	giveWeapon(source, 32, 500, true)
end
addEvent("arma12", true)
addEventHandler("arma12", getRootElement(), arma12)

function arma13()
	giveWeapon(source, 28, 500, true)
end
addEvent("arma13", true)
addEventHandler("arma13", getRootElement(), arma13)

function arma14()
	giveWeapon(source, 30, 500, true)
end
addEvent("arma14", true)
addEventHandler("arma14", getRootElement(), arma14)

function arma15()
	giveWeapon(source, 31, 500, true)
end
addEvent("arma15", true)
addEventHandler("arma15", getRootElement(), arma15)

function arma16()
	giveWeapon(source, 33, 500, true)
end
addEvent("arma16", true)
addEventHandler("arma16", getRootElement(), arma16)

function arma17()
	giveWeapon(source, 34, 500, true)
end
addEvent("arma17", true)
addEventHandler("arma17", getRootElement(), arma17)

function arma18()
	giveWeapon(source, 41, 1, true)
end
addEvent("arma18", true)
addEventHandler("arma18", getRootElement(), arma18)

function arma19()
	giveWeapon(source, 43, 1, true)
end
addEvent("arma19", true)
addEventHandler("arma19", getRootElement(), arma19)

function arma20()
	giveWeapon(source, 45, 1, true)
end
addEvent("arma20", true)
addEventHandler("arma20", getRootElement(), arma20)

function arma21()
	giveWeapon(source, 44, 1, true)
end
addEvent("arma21", true)
addEventHandler("arma21", getRootElement(), arma21)

function arma22()
	giveWeapon(source, 46, 1, true)
end
addEvent("arma22", true)
addEventHandler("arma22", getRootElement(), arma22)

function arma23()
	giveWeapon(source, 14, 1, true)
end
addEvent("arma23", true)
addEventHandler("arma23", getRootElement(), arma23)

function arma24()
	giveWeapon(source, 10, 1, true)
end
addEvent("arma24", true)
addEventHandler("arma24", getRootElement(), arma24)

function skin1()
	setElementModel(source, 14)
end
addEvent("skin1", true)
addEventHandler("skin1", getRootElement(), skin1)

function skin2()
	setElementModel(source, 23)
end
addEvent("skin2", true)
addEventHandler("skin2", getRootElement(), skin2)

function skin3()
	setElementModel(source, 21)
end
addEvent("skin3", true)
addEventHandler("skin3", getRootElement(), skin3)

function skin4()
	setElementModel(source, 171)
end
addEvent("skin4", true)
addEventHandler("skin4", getRootElement(), skin4)

function skin5()
	setElementModel(source, 43)
end
addEvent("skin5", true)
addEventHandler("skin5", getRootElement(), skin5)

function skin6()
	setElementModel(source, 185)
end
addEvent("skin6", true)
addEventHandler("skin6", getRootElement(), skin6)

function skin7()
	setElementModel(source, 66)
end
addEvent("skin7", true)
addEventHandler("skin7", getRootElement(), skin7)

function skin8()
	setElementModel(source, 10)
end
addEvent("skin8", true)
addEventHandler("skin8", getRootElement(), skin8)

function skin9()
	setElementModel(source, 2)
end
addEvent("skin9", true)
addEventHandler("skin9", getRootElement(), skin9)

function skin10()
	setElementModel(source, 48)
end
addEvent("skin10", true)
addEventHandler("skin10", getRootElement(), skin10)

function skin11()
	setElementModel(source, 9)
end
addEvent("skin11", true)
addEventHandler("skin11", getRootElement(), skin11)

function skin12()
	setElementModel(source, 124)
end
addEvent("skin12", true)
addEventHandler("skin12", getRootElement(), skin12)

function skin13()
	setElementModel(source, 35)
end
addEvent("skin13", true)
addEventHandler("skin13", getRootElement(), skin13)

function skin14()
	setElementModel(source, 122)
end
addEvent("skin14", true)
addEventHandler("skin14", getRootElement(), skin14)

function skin15()
	setElementModel(source, 15)
end
addEvent("skin15", true)
addEventHandler("skin15", getRootElement(), skin15)

function skin16()
	setElementModel(source, 130)
end
addEvent("skin16", true)
addEventHandler("skin16", getRootElement(), skin16)

function skin17()
	setElementModel(source, 249)
end
addEvent("skin17", true)
addEventHandler("skin17", getRootElement(), skin17)

function skin18()
	setElementModel(source, 53)
end
addEvent("skin18", true)
addEventHandler("skin18", getRootElement(), skin18)

function skin19()
	setElementModel(source, 240)
end
addEvent("skin19", true)
addEventHandler("skin19", getRootElement(), skin19)

function skin20()
	setElementModel(source, 299)
end
addEvent("skin20", true)
addEventHandler("skin20", getRootElement(), skin20)

function skin21()
	setElementModel(source, 241)
end
addEvent("skin21", true)
addEventHandler("skin21", getRootElement(), skin21)

function skin22()
	setElementModel(source, 290)
end
addEvent("skin22", true)
addEventHandler("skin22", getRootElement(), skin22)

function skin23()
	setElementModel(source, 19)
end
addEvent("skin23", true)
addEventHandler("skin23", getRootElement(), skin23)

function skin24()
	setElementModel(source, 22)
end
addEvent("skin24", true)
addEventHandler("skin24", getRootElement(), skin24)

function skin25()
	setElementModel(source, 45)
end
addEvent("skin25", true)
addEventHandler("skin25", getRootElement(), skin25)

function skin26()
	setElementModel(source, 305)
end
addEvent("skin26", true)
addEventHandler("skin26", getRootElement(), skin26)

function skin27()
	setElementModel(source, 18)
end
addEvent("skin27", true)
addEventHandler("skin27", getRootElement(), skin27)

function skin28()
	setElementModel(source, 95)
end
addEvent("skin28", true)
addEventHandler("skin28", getRootElement(), skin28)

veiculo = {}
function carro1()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(474, vx, vy, vz, 0, 0, vrot)
	setElementInterior(veiculo[source], getElementInterior(source))
	setElementDimension(veiculo[source], getElementDimension(source))
end
addEvent("carro1", true)
addEventHandler("carro1", getRootElement(), carro1)

function carro2()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(527, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro2", true)
addEventHandler("carro2", getRootElement(), carro2)

function carro3()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(565, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro3", true)
addEventHandler("carro3", getRootElement(), carro3)

function carro4()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(526, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro4", true)
addEventHandler("carro4", getRootElement(), carro4)

function carro5()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(529, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro5", true)
addEventHandler("carro5", getRootElement(), carro5)

function carro6()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(545, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro6", true)
addEventHandler("carro6", getRootElement(), carro6)

function carro7()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(559, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro7", true)
addEventHandler("carro7", getRootElement(), carro7)

function carro8()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(405, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro8", true)
addEventHandler("carro8", getRootElement(), carro8)

function carro9()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(436, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro9", true)
addEventHandler("carro9", getRootElement(), carro9)

function carro10()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(475, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro10", true)
addEventHandler("carro10", getRootElement(), carro10)

function carro11()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(547, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro11", true)
addEventHandler("carro11", getRootElement(), carro11)

function carro12()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(550, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro12", true)
addEventHandler("carro12", getRootElement(), carro12)

function carro13()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(500, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro13", true)
addEventHandler("carro13", getRootElement(), carro13)

function carro14()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(507, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro14", true)
addEventHandler("carro14", getRootElement(), carro14)

function carro15()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(587, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro15", true)
addEventHandler("carro15", getRootElement(), carro15)

function carro16()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(422, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro16", true)
addEventHandler("carro16", getRootElement(), carro16)

function carro17()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(540, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro17", true)
addEventHandler("carro17", getRootElement(), carro17)

function carro18()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(516, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro18", true)
addEventHandler("carro18", getRootElement(), carro18)

function carro19()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(541, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro19", true)
addEventHandler("carro19", getRootElement(), carro19)

function carro20()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(602, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro20", true)
addEventHandler("carro20", getRootElement(), carro20)

function carro21()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(480, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro21", true)
addEventHandler("carro21", getRootElement(), carro21)

function carro22()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(429, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro22", true)
addEventHandler("carro22", getRootElement(), carro22)

function carro23()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(589, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro23", true)
addEventHandler("carro23", getRootElement(), carro23)

function carro24()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(415, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro24", true)
addEventHandler("carro24", getRootElement(), carro24)

function carro25()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(543, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro25", true)
addEventHandler("carro25", getRootElement(), carro25)

function carro26()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(546, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro26", true)
addEventHandler("carro26", getRootElement(), carro26)

function carro27()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(426, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro27", true)
addEventHandler("carro27", getRootElement(), carro27)

function carro28()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(445, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro28", true)
addEventHandler("carro28", getRootElement(), carro28)

function carro29()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(586, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro29", true)
addEventHandler("carro29", getRootElement(), carro29)

function carro30()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(510, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro30", true)
addEventHandler("carro30", getRootElement(), carro30)

function carro31()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(461, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro31", true)
addEventHandler("carro31", getRootElement(), carro31)

function carro32()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(463, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro32", true)
addEventHandler("carro32", getRootElement(), carro32)

function carro33()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(462, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro33", true)
addEventHandler("carro33", getRootElement(), carro33)

function carro34()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(468, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro34", true)
addEventHandler("carro34", getRootElement(), carro34)

function carro35()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(522, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro35", true)
addEventHandler("carro35", getRootElement(), carro35)

function carro36()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(521, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro36", true)
addEventHandler("carro36", getRootElement(), carro36)

function carro37()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
	local radius = 3
	px, py, pz = getElementPosition(source)
	prot = getPedRotation(source)
	local offsetRot = math.rad(prot)
	local vx = px + radius*math.cos(offsetRot)
	local vy = py + radius*math.sin(offsetRot)
	local vz = pz + 2
	local vrot = prot
	veiculo[source] = createVehicle(581, vx, vy, vz, 0, 0, vrot)
end
addEvent("carro37", true)
addEventHandler("carro37", getRootElement(), carro37)

function destroirCarro()
	if veiculo[source] and isElement(veiculo[source]) then
		destroyElement(veiculo[source])
	end
end
addEventHandler("onPlayerLogout", getRootElement(), destroirCarro)
addEventHandler("onPlayerQuit", getRootElement(), destroirCarro)
addEventHandler("onPlayerWasted", getRootElement(), destroirCarro)

function reparar()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		fixVehicle(veiculo)
	end
end
addEvent("reparar", true)
addEventHandler("reparar", getRootElement(), reparar)

function virar()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		local rotX, rotY, rotZ = getElementRotation(veiculo)
		setVehicleRotation(veiculo, 0, 0, (rotX > 90 and rotX < 270) and (rotZ + 180) or rotZ)
	end
end
addEvent("virar", true)
addEventHandler("virar", getRootElement(), virar)

function hidraulica()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1087)
	end
end
addEvent("hidraulica", true)
addEventHandler("hidraulica", getRootElement(), hidraulica)

function nitro()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1010)
	end
end
addEvent("nitro", true)
addEventHandler("nitro", getRootElement(), nitro)

function roda1()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1025)
	end
end
addEvent("roda1", true)
addEventHandler("roda1", getRootElement(), roda1)

function roda2()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1073)
	end
end
addEvent("roda2", true)
addEventHandler("roda2", getRootElement(), roda2)

function roda3()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1074)
	end
end
addEvent("roda3", true)
addEventHandler("roda3", getRootElement(), roda3)

function roda4()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1075)
	end
end
addEvent("roda4", true)
addEventHandler("roda4", getRootElement(), roda4)

function roda5()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1076)
	end
end
addEvent("roda5", true)
addEventHandler("roda5", getRootElement(), roda5)

function roda6()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1077)
	end
end
addEvent("roda6", true)
addEventHandler("roda6", getRootElement(), roda6)

function roda7()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1078)
	end
end
addEvent("roda7", true)
addEventHandler("roda7", getRootElement(), roda7)

function roda8()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1079)
	end
end
addEvent("roda8", true)
addEventHandler("roda8", getRootElement(), roda8)

function roda9()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1080)
	end
end
addEvent("roda9", true)
addEventHandler("roda9", getRootElement(), roda9)

function roda10()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1081)
	end
end
addEvent("roda10", true)
addEventHandler("roda10", getRootElement(), roda10)

function roda11()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1082)
	end
end
addEvent("roda11", true)
addEventHandler("roda11", getRootElement(), roda11)

function roda12()
	local veiculo = getPedOccupiedVehicle(source)
	if isPedInVehicle(source) then
		addVehicleUpgrade(veiculo, 1083)
	end
end
addEvent("roda12", true)
addEventHandler("roda12", getRootElement(), roda12)

function cor1(r1, g1, b1, r2, g2, b2, veiculo)
	setVehicleColor(veiculo, r1, g1, b1, r2, g2, b2)
end
addEvent("cor1", true)
addEventHandler("cor1", getRootElement(), cor1)

function cor2(r, g, b, veiculo)
	setVehicleHeadLightColor(veiculo, r, g, b)
end
addEvent("cor2", true)
addEventHandler("cor2", getRootElement(), cor2)

function nickName(nick)
	setPlayerName(source, nick)
end
addEvent("nickName", true)
addEventHandler("nickName", getRootElement(), nickName)